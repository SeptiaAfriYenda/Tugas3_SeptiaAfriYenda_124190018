package com.example.tugas3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class OppoDetail extends AppCompatActivity {
    TextView tv_oppo, tv_spek_oppo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oppo_detail);

        tv_oppo = findViewById(R.id.tv_oppo);
        tv_spek_oppo = findViewById(R.id.tv_spek_oppo);

        getIncomingExtra();
    }
    private void getIncomingExtra(){
        String tipeoppo = getIntent().getStringExtra("type_oppo");
        String spekoppo = getIntent().getStringExtra("speci_oppo");

        setDataActivity(tipeoppo, spekoppo);
    }
    private void setDataActivity(String tipeopoo, String spekoppo){
        tv_oppo.setText(tipeopoo);
        tv_spek_oppo.setText(spekoppo);
    }
}