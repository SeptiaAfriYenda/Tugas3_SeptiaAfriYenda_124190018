package com.example.tugas3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //menghubungkan ke layout activity main
    private RecyclerView recyclerView;
    //data yg akan ditampilkan adapter ke recycler
    private ArrayList<OppoModel> oppoModels = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.rv);
        recyclerView.setHasFixedSize(true);
        oppoModels.addAll(OppoData.getListData());
        showRecycleList();
    }

    //mengatur tata letak tampilan
    private  void showRecycleList(){
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        OppoAdapter oppoAdapter = new OppoAdapter(this);
        oppoAdapter.setOppoModels(oppoModels);
        recyclerView.setAdapter(oppoAdapter);
    }
}